# x_make_contract_validators_x — Evidence-Grade JSON Contract Auditor

This package enforces JSON schema discipline across every payload we ship. Feed it a schema, pass a candidate document, and it delivers crisp validation evidence ready for orchestrator logs or Change Control dossiers.

## Mission Log
- Load Draft 2020-12 JSON Schemas and verify they compile cleanly before execution.
- Validate payloads against the declared schema with human-readable failure diagnostics.
- Offer both Python APIs and a CLI front line for batch validation or scripted CI runs.
- Emit structured summaries suitable for ingestion by orchestrator progress boards and release reporters.

## Instrumentation
- Python 3.11 or newer.
- `jsonschema` 4.21 or later for Draft 2020-12 support.
- Optional QA: Ruff, Black, MyPy, Pyright, pytest.

## Operating Procedure
1. `python -m venv .venv`
2. `\.venv\Scripts\Activate.ps1`
3. `python -m pip install --upgrade pip`
4. `pip install -r requirements.txt`
5. `python -m x_make_contract_validators_x --schema schema.json --payload payload.json`

The CLI exits with `0` on success. Failure reports include the offending path, schema location, and a short message ready for Change Control entries.

## Evidence Checks
| Check | Command |
| --- | --- |
| Formatting sweep | `python -m black .` |
| Lint interrogation | `python -m ruff check .` |
| Type audit | `python -m mypy .` |
| Static contract scan | `python -m pyright` |
| Functional verification | `pytest` |

## Reconstitution Drill
During the monthly rebuild I validate a representative payload suite: one that passes, one that fails schema compilation, and one that fails payload validation. Results flow into Change Control to prove the guardrails are intact.

## Conduct Code
Every schema update or CLI enhancement must land with tests, documentation adjustments, and captured evidence. No silent behaviour shifts.

## Sole Architect's Note
These validators are my blade—sharpened to keep pipelines honest. They distill the shared helper into a focused package with the same zero-compromise tone you expect from the command deck.
